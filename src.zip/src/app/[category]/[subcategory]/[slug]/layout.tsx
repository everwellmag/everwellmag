// src/app/[category]/[subcategory]/[slug]/layout.tsx
import { ReactNode } from 'react';
import { Metadata } from 'next';
import CategoryLayout from '@/components/layout/category-layout';
import { getCategoryBySlug } from '@/lib/api/strapi/get-category';
import { generateCategoryMetadata } from '@/lib/seo/generate-category-metadata';

interface DetailLayoutProps {
    children: ReactNode;
    params: Promise<{ category: string; subcategory: string; slug: string }>;
}

export async function generateMetadata({ params }: DetailLayoutProps): Promise<Metadata> {
    const resolvedParams = await params;
    const { subcategory, slug } = resolvedParams;

    // Fetch subcategory để lấy type cho metadata
    const subcategoryData = await getCategoryBySlug(subcategory);
    if (!subcategoryData) {
        return {
            title: 'Content Not Found | Everwell Magazine',
            description: 'The content you are looking for does not exist.',
        };
    }

    // Map type cho metadata (mixed fallback 'product')
    const mappedType = subcategoryData.type === 'mixed' ? 'product' : subcategoryData.type;

    return generateCategoryMetadata({
        slug: subcategory,
        parentSlug: resolvedParams.category,
        categoryType: mappedType,
    });
}

export default async function DetailLayout({ children, params }: DetailLayoutProps) {
    const resolvedParams = await params;
    const { subcategory } = resolvedParams;

    // Fetch subcategory để lấy type cho layout
    const subcategoryData = await getCategoryBySlug(subcategory);
    if (!subcategoryData) {
        return <div>Content not found</div>;
    }

    const mappedType = subcategoryData.type === 'mixed' ? 'product' : subcategoryData.type;

    return (
        <CategoryLayout
            slug={subcategory}
            parentSlug={resolvedParams.category}
            categoryType={mappedType}
        >
            {children}
        </CategoryLayout>
    );
}