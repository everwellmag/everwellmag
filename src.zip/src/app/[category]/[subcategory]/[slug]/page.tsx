// src/app/[category]/[subcategory]/[slug]/page.tsx
import { notFound } from 'next/navigation';
import { getArticleBySlug } from '@/lib/api/strapi/get-article';
import { getProductBySlug } from '@/lib/api/strapi/get-product';
import { getCategoryBySlug } from '@/lib/api/strapi/get-category';
import ArticleContent from '@/components/content/articles/article-content';
import ProductDetail from '@/components/content/products/product-detail';
import CommentSection from '@/components/content/comments/comment-section';

export default async function DetailPage({ params }: { params: Promise<{ category: string; subcategory: string; slug: string }> }) {
    const resolvedParams = await params;
    const { slug, category: categorySlug, subcategory } = resolvedParams;

    // Fetch subcategory để check type từ Strapi
    const subcategoryData = await getCategoryBySlug(subcategory);
    if (!subcategoryData) {
        notFound();
    }

    const type = subcategoryData.type; // 'article', 'product', hoặc 'mixed'

    let content;
    if (type === 'article') {
        // Fetch và render bài viết
        const article = await getArticleBySlug(slug);
        if (!article) notFound();
        content = (
            <>
                <ArticleContent article={article} />
                <CommentSection contentId={article.id} contentType="article" />
            </>
        );
    } else if (type === 'product') {
        // Fetch và render sản phẩm
        const product = await getProductBySlug(slug);
        if (!product) notFound();
        content = (
            <>
                <ProductDetail product={product} categorySlug={categorySlug} />
                <CommentSection contentId={product.id} contentType="product" />
            </>
        );
    } else if (type === 'mixed') {
        // Ưu tiên thử article trước, fallback product
        const article = await getArticleBySlug(slug);
        if (article) {
            content = (
                <>
                    <ArticleContent article={article} />
                    <CommentSection contentId={article.id} contentType="article" />
                </>
            );
        } else {
            const product = await getProductBySlug(slug);
            if (product) {
                content = (
                    <>
                        <ProductDetail product={product} categorySlug={categorySlug} />
                        <CommentSection contentId={product.id} contentType="product" />
                    </>
                );
            } else {
                notFound();
            }
        }
    } else {
        notFound(); // Type không hợp lệ
    }

    return <div>{content}</div>;
}