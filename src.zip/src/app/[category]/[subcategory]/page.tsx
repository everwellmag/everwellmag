import { notFound } from 'next/navigation';
import { getCategoryBySlug } from '@/lib/api/strapi/get-category';
import ArticleList from '@/components/content/articles/article-list';
import ProductList from '@/components/content/products/product-list';
import type { Article } from '@/lib/types/article';
import type { Product } from '@/lib/types/product';

export default async function SubCategoryPage({ params }: { params: Promise<{ category: string; subcategory: string }> }) {
    const resolvedParams = await params;
    const { subcategory: slug, category: parentSlug } = resolvedParams;

    const subcategoryData = await getCategoryBySlug(slug);
    if (!subcategoryData || subcategoryData.parent?.slug !== parentSlug) notFound();

    // Check type từ Strapi để render đúng list
    const type = subcategoryData.type;
    let articles: Article[] = [];
    let products: Product[] = [];

    if (type === 'article' || type === 'mixed') {
        articles = subcategoryData.articles ?? [];
    }
    if (type === 'product' || type === 'mixed') {
        products = subcategoryData.products ?? [];
    }

    const title = subcategoryData.name ?? slug;
    const description = subcategoryData.description ?? `Explore ${type} in ${title}.`;

    return (
        <div>
            <h1>{title}</h1>
            <p>{description}</p>

            {articles.length > 0 && (
                <section>
                    <h2>Articles</h2>
                    <ArticleList articles={articles} />
                </section>
            )}

            {products.length > 0 && (
                <section>
                    <h2>Products</h2>
                    <ProductList products={products} />
                </section>
            )}

            {articles.length === 0 && products.length === 0 && (
                <p>No content available.</p>
            )}
        </div>
    );
}