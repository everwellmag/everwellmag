import { notFound } from 'next/navigation';
import { getCategoryBySlug } from '@/lib/api/strapi/get-category'; // Sửa dùng alias @
import ArticleList from '@/components/content/articles/article-list'; // Sửa dùng alias @
import ProductList from '@/components/content/products/product-list'; // Sửa dùng alias @
import type { Article } from '@/lib/types/article'; // Sửa dùng alias @
import type { Product } from '@/lib/types/product'; // Sửa dùng alias @

export default async function CategoryPage({ params }: { params: Promise<{ category: string }> }) {
    const resolvedParams = await params; // Await params
    const { category: slug } = resolvedParams;

    const categoryData = await getCategoryBySlug(slug);
    if (!categoryData) notFound();

    // Lấy content từ category (mixed cho cha)
    const articles: Article[] = categoryData.articles ?? [];
    const products: Product[] = categoryData.products ?? [];

    const title = categoryData.name ?? slug;
    const description = categoryData.description ?? `Explore content in ${title} on Everwell Magazine.`;

    return (
        <div>
            <h1>{title}</h1>
            <p>{description}</p>

            {/* Render mixed cho category cha */}
            {articles.length > 0 && (
                <section>
                    <h2>Articles</h2>
                    <ArticleList articles={articles} />
                </section>
            )}

            {products.length > 0 && (
                <section>
                    <h2>Products</h2>
                    <ProductList products={products} />
                </section>
            )}

            {articles.length === 0 && products.length === 0 && (
                <p>No content available in this category.</p>
            )}
        </div>
    );
}