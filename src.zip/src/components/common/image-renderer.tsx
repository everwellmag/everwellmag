'use client';

import React from 'react';
import Image from 'next/image';

interface ImageRendererProps {
    src?: string | null;
    alt?: string;
    width?: number;
    height?: number;
    className?: string;
    fallbackSrc?: string;
}

export default function ImageRenderer({
    src,
    alt = 'Image',
    width = 800,
    height = 450,
    className = '',
    fallbackSrc = '/images/placeholder.webp',
}: ImageRendererProps) {
    const validSrc = src && src.startsWith('http') ? src : fallbackSrc;

    return (
        <Image
            src={validSrc}
            alt={alt}
            width={width}
            height={height}
            className={`object-cover ${className}`}
            loading="lazy"
            onError={(e) => {
                const target = e.target as HTMLImageElement;
                if (target.src !== fallbackSrc) target.src = fallbackSrc;
            }}
        />
    );
}
