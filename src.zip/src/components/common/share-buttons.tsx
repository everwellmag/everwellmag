'use client';

import React from 'react';
import { Share2, Facebook, Twitter, Linkedin } from 'lucide-react';

interface ShareButtonsProps {
    url: string;
    title: string;
}

export default function ShareButtons({ url, title }: ShareButtonsProps) {
    const encodedUrl = encodeURIComponent(url);
    const encodedTitle = encodeURIComponent(title);

    const shareLinks = {
        facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`,
        twitter: `https://x.com/intent/tweet?url=${encodedUrl}&text=${encodedTitle}`,
        linkedin: `https://www.linkedin.com/shareArticle?mini=true&url=${encodedUrl}&title=${encodedTitle}`,
    };

    return (
        <div className="flex items-center gap-4">
            <Share2 className="text-gray-500" />
            <a
                href={shareLinks.facebook}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-blue-600"
                aria-label="Share on Facebook"
            >
                <Facebook size={20} />
            </a>
            <a
                href={shareLinks.twitter}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-sky-500"
                aria-label="Share on Twitter"
            >
                <Twitter size={20} />
            </a>
            <a
                href={shareLinks.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-blue-700"
                aria-label="Share on LinkedIn"
            >
                <Linkedin size={20} />
            </a>
        </div>
    );
}
