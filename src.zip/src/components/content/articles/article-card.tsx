import { Article } from '@/lib/types/article';
import Image from 'next/image';

interface ArticleCardProps {
    article: Article;
}

export default function ArticleCard({ article }: ArticleCardProps) {
    // ✅ Fix: Flat structure, safe access, local placeholder
    const coverUrl = article.cover?.url ? `https://cms.everwellmag.com${article.cover.url}` : '/images/placeholder.webp';
    const categorySlug = article.categories?.[0]?.slug || 'uncategorized';
    return (
        <div className="border rounded-lg p-4">
            <Image
                src={coverUrl}
                alt={article.title || 'Untitled'}
                width={300}
                height={200}
                className="rounded"
            />
            <h3 className="text-lg font-semibold mt-2">{article.title || 'Untitled'}</h3>
            <a href={`/${categorySlug}/${article.slug || ''}`}>Read more</a>
        </div>
    );
}