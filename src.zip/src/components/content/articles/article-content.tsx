'use client';

import React from 'react';
import { Article } from '@/lib/types/article';
import ImageRenderer from '@/components/common/image-renderer';
import MarkdownRenderer from '@/components/common/markdown-renderer';
import ShareButtons from '@/components/common/share-buttons';
import CommentSection from '@/components/content/comments/comment-section';
import { formatDate } from '@/lib/utils/format-date';

interface ArticleContentProps {
    article: Article;
}

export default function ArticleContent({ article }: ArticleContentProps) {
    const { title, content, cover, publishedAt, description } = article.attributes;
    const coverUrl = cover?.data?.attributes?.url;
    const altText = cover?.data?.attributes?.alternativeText || title;

    return (
        <article className="mx-auto max-w-3xl px-4 py-8 prose prose-lg dark:prose-invert">
            {/* Tiêu đề */}
            <h1 className="text-3xl font-bold mb-3">{title}</h1>

            {/* Ngày xuất bản */}
            {publishedAt && (
                <p className="text-sm text-gray-500 mb-6">
                    {formatDate(publishedAt)}
                </p>
            )}

            {/* Ảnh cover */}
            {coverUrl && (
                <div className="mb-6">
                    <ImageRenderer
                        src={coverUrl}
                        alt={altText}
                        width={1200}
                        height={630}
                        className="rounded-xl shadow-md w-full"
                    />
                </div>
            )}

            {/* Mô tả ngắn */}
            {description && (
                <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                    {description}
                </p>
            )}

            {/* Nội dung bài viết */}
            {content && <MarkdownRenderer content={content} />}

            {/* Chia sẻ */}
            <div className="mt-10">
                <ShareButtons
                    url={`https://www.everwellmag.com/article/${article.attributes.slug}`}
                    title={title}
                />
            </div>

            {/* Bình luận */}
            <div className="mt-10 border-t pt-6">
                <CommentSection
                    documentId={article.id.toString()}
                    documentType="article"
                />
            </div>
        </article>
    );
}
