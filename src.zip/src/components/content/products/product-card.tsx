'use client';

import Image from 'next/image';
import Link from 'next/link';
import { Product } from '@/lib/types/product';

interface ProductCardProps {
    product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
    if (!product) return null;

    // ✅ Fix: Flat structure, local placeholder
    const imageUrl = product.Image?.url ? `https://cms.everwellmag.com${product.Image.url}` : '/images/placeholder.webp';

    const name = product.Name || 'Unnamed Product';
    const slug = product.slug || '';
    const categorySlug = product.categories?.[0]?.slug || '';

    const href = categorySlug ? `/${categorySlug}/${slug}` : `/product/${slug}`;

    return (
        <Link
            href={href}
            className="block bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl overflow-hidden shadow hover:shadow-lg transition-shadow duration-200"
        >
            <div className="relative w-full aspect-square">
                <Image
                    src={imageUrl}
                    alt={product.Image?.alternativeText || name}
                    fill
                    className="object-cover"
                    unoptimized
                    onError={(e) => {
                        (e.target as HTMLImageElement).src = '/images/placeholder.webp'; // Local fallback
                    }}
                />
            </div>
            <div className="p-4">
                <h3 className="font-semibold text-lg line-clamp-2 mb-1">{name}</h3>
                {product.Supplier && (
                    <p className="text-sm text-gray-500 dark:text-gray-400">{product.Supplier}</p>
                )}
                {product.rating && (
                    <p className="text-sm text-yellow-500">⭐ {product.rating}/5</p>
                )}
            </div>
        </Link>
    );
}