'use client';

import React from 'react';
import ProductCard from './product-card';
import { Product } from '@/lib/types/product';

export interface ProductListProps {
    products: Product[];
    title?: string;
    description?: string;
    categoryId?: number;
}

export default function ProductList({ products, title, description }: ProductListProps) {
    if (!products || products.length === 0) {
        return (
            <section className="container mx-auto px-4 py-10 text-center">
                {title && <h1 className="text-3xl font-semibold mb-2">{title}</h1>}
                {description && <p className="text-gray-600 mb-6">{description}</p>}
                <p className="text-gray-500 italic">No products found in this category.</p>
            </section>
        );
    }

    return (
        <section className="container mx-auto px-4 py-10">
            {title && <h1 className="text-3xl font-semibold mb-2 text-center">{title}</h1>}
            {description && (
                <p className="text-gray-600 mb-10 text-center max-w-2xl mx-auto">{description}</p>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                {products.map((product) => (
                    <ProductCard key={product.id} product={product} />
                ))}
            </div>
        </section>
    );
}
