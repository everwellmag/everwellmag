'use client';

import Link from 'next/link';

type ErrorProps = {
    error?: Error & { digest?: string };
};

const Error = ({ error }: ErrorProps) => {
    return (
        <div className="min-h-screen flex flex-col items-center justify-center bg-[var(--background)] text-[var(--foreground)]">
            <div className="bg-[var(--card-bg)] rounded-xl shadow-md p-8 border text-center" style={{ borderColor: 'var(--link-color)' }}>
                <h1 className="text-3xl font-bold mb-4">Something Went Wrong!</h1>
                <p className="text-lg mb-6" style={{ color: 'var(--text-secondary)' }}>
                    {error?.message || 'An unexpected error occurred. Please return to the homepage.'}
                </p>
                <Link
                    href="/"
                    className="py-3 px-6 rounded-lg btn-gradient text-white font-semibold"
                >
                    Back to Home
                </Link>
            </div>
        </div>
    );
};

export default Error;