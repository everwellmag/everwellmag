export async function fetchFromStrapi(endpoint: string) {
    const strapiUrl = process.env.STRAPI_URL || 'https://cms.everwellmag.com';
    const url = endpoint.startsWith('http') ? endpoint : `${strapiUrl}/api/${endpoint}`;
    console.log('Fetching from:', url);
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000); // 10s timeout
    try {
        const response = await fetch(url, {
            next: { revalidate: 60 }, // ISR cache 60s
            headers: { 'Content-Type': 'application/json' },
            signal: controller.signal,
        });
        if (!response.ok) {
            const errorText = await response.text();
            console.error('Strapi Error:', errorText);
            throw new Error(`Failed to fetch from Strapi: ${response.statusText} - ${errorText}`);
        }
        return await response.json();
    } catch (error) {
        console.error('Fetch error:', error);
        throw error; // Re-throw for higher-level handling
    } finally {
        clearTimeout(timeoutId);
    }
}