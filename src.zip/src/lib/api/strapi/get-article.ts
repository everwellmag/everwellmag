import { Article } from '@/lib/types/article';
import { fetchFromStrapi } from '@/lib/api/strapi/fetch-strapi';

/**
 * Lấy bài viết theo slug (và category nếu có)
 * @param articleSlug slug bài viết
 * @param categorySlug slug danh mục cha (để validate)
 */
export async function getArticleBySlug(articleSlug: string, categorySlug?: string): Promise<Article | null> {
    try {
        const data = await fetchFromStrapi(
            `articles?filters[slug][$eq]=${articleSlug}&populate=cover,categories`
        );

        if (!data || !data.data || data.data.length === 0) {
            console.warn(`Article not found for slug: ${articleSlug}`);
            return null;
        }

        const article = data.data[0] as Article;

        // Nếu có truyền categorySlug → kiểm tra trùng danh mục cha
        const categories = article.attributes.categories?.data || [];
        const validCategory = !categorySlug || categories.some(
            (cat: any) => cat.attributes.slug === categorySlug
        );

        if (!validCategory) {
            console.warn(`Article "${articleSlug}" does not belong to category "${categorySlug}"`);
            return null;
        }

        return article;
    } catch (error) {
        console.error('Error fetching article from Strapi:', error);
        return null;
    }
}
