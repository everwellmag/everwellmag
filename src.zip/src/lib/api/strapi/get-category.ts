// src/lib/api/strapi/get-category.ts (update populate để fetch articles/products)
import { fetchFromStrapi } from './fetch-strapi';
import { Category } from '@/lib/types/category';

/**
 * Lấy 1 category từ Strapi bằng slug, bao gồm cha - con - articles - products (full populate)
 */
export async function getCategoryBySlug(slug: string): Promise<Category | null> {
    try {
        const data = await fetchFromStrapi(
            `categories?filters[slug][$eq]=${slug}&populate=parent&populate=children&populate[articles][populate]=cover&populate[products][populate]=Image`
        );

        if (!data || !data.data || data.data.length === 0) {
            console.warn(`[getCategoryBySlug] Category not found for slug: ${slug}`);
            return null;
        }

        const category = data.data[0] as Category;
        console.log('[getCategoryBySlug] Fetched category with content:', { slug, articlesCount: category.articles?.length || 0, productsCount: category.products?.length || 0 });
        return category;
    } catch (error) {
        console.error('[getCategoryBySlug] ❌ Error fetching category:', error);
        return null;
    }
}