import { fetchFromStrapi } from './fetch-strapi';
import { Product } from '../../types/product'; // Import types (sẽ tạo ở bước 2)

export async function getProductsByCategory(categorySlug: string): Promise<Product[] | null> {
    try {
        const data = await fetchFromStrapi(`products?filters[categories][slug][$eq]=${categorySlug}&populate=*&pagination[pageSize]=20`);
        if (!data || !data.data || !Array.isArray(data.data)) {
            console.error('Invalid products data from Strapi:', data);
            return null;
        }
        // Sort by Priority then createdAt (from your old code)
        const sortedProducts = data.data.sort((a: Product, b: Product) => {
            const priorityA = a.Priority ?? Infinity;
            const priorityB = b.Priority ?? Infinity;
            if (priorityA !== priorityB) {
                return priorityA - priorityB;
            }
            return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        });
        return sortedProducts;
    } catch (error) {
        console.error('Error fetching products:', error);
        return null;
    }
}