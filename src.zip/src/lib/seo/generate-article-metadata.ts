import { Metadata } from 'next';
import { getArticleBySlug } from '../api/strapi/get-article';

interface GenerateArticleMetadataProps {
    slug: string;
    subcategory?: string;
}

export async function generateArticleMetadata({ slug, subcategory }: GenerateArticleMetadataProps): Promise<Metadata> {
    const article = await getArticleBySlug(slug);

    if (!article) {
        return {
            title: 'Article Not Found | Everwell Magazine',
            description: 'The article you are looking for does not exist.',
        };
    }

    return {
        title: `${article.title} | Everwell Magazine`,
        description: article.description || 'Read the latest health and wellness articles.',
        openGraph: {
            title: `${article.title} | Everwell Magazine`,
            description: article.description || 'Read the latest health and wellness articles.',
            type: 'article',
            publishedTime: article.publishedAt,
            images: article.cover?.url ? [{ url: article.cover.url }] : [],
        },
        alternates: {
            canonical: `/weight-loss/${subcategory}/${slug}`, // Adjust based on actual category
        },
    };
}