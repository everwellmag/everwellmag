// src/lib/types/product.ts (thêm field categories để fix lỗi Property 'categories' does not exist)

export interface Media {
    id: number;
    documentId: string;
    name: string;
    alternativeText?: string;
    caption?: string;
    width: number;
    height: number;
    formats: {
        thumbnail: {
            name: string;
            hash: string;
            ext: string;
            mime: string;
            path: string | null;
            width: number;
            height: number;
            size: number;
            sizeInBytes: number;
            url: string;
        };
        medium: {
            name: string;
            hash: string;
            ext: string;
            mime: string;
            path: string | null;
            width: number;
            height: number;
            size: number;
            sizeInBytes: number;
            url: string;
        };
        small: {
            name: string;
            hash: string;
            ext: string;
            mime: string;
            path: string | null;
            width: number;
            height: number;
            size: number;
            sizeInBytes: number;
            url: string;
        };
    };
    hash: string;
    ext: string;
    mime: string;
    size: number;
    url: string;
    previewUrl: string | null;
    provider: string;
    provider_metadata: string | null;
    createdAt: string;
    updatedAt: string;
    publishedAt: string;
}

export interface Product {
    id: number;
    documentId: string;
    Name: string;
    Description: string;
    Supplier: string;
    ReleaseYear: string;
    AffiliateLink: string;
    createdAt: string;
    updatedAt: string;
    publishedAt: string;
    slug: string;
    rating: number;
    Pricemulti: Array<{
        quantity: number;
        price: number;
        currency: string;
    }>;
    Priority: number;
    Image: Media;
    categories?: Array<{  // ✅ Thêm field categories (optional array từ Strapi relations)
        name: string;
        slug: string;
        parent_slug?: string;  // Để build breadcrumb
    }>;  // Nếu Strapi populate full Category, thay bằng Category[]
}